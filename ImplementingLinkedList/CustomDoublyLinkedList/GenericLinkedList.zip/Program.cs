﻿using System;
namespace CustomDoublyLinkedList
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            LinkedList<string> list = new LinkedList<string>();
            for (int i = 45; i < 54; i++)
            {
                list.AddFirst(new Node<string>(i.ToString()));
            }
            list.PrintList();
        }
    }
}
