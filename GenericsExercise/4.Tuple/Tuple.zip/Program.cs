﻿using System;

namespace _4.Tuple
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            // {first name} {last name} {address}
            string[] line1 = Console.ReadLine().Split();
            string fullName = $"{line1[0]} {line1[1]}";
            string address = line1[2];

            Tuple<string, string> line1T = new Tuple<string, string>(fullName, address);

            //{name} {liters of beer}
            string[] line2 = Console.ReadLine().Split();
            string name = line2[0];
            int litresOfBeer = int.Parse(line2[1]);

            Tuple<string, int> line2T = new Tuple<string, int>(name, litresOfBeer);

            // {integer} {double}
            string[] line3 = Console.ReadLine().Split();
            int num1 = int.Parse(line3[0]);
            double num2 = double.Parse(line3[1]);

            Tuple<int, double> line3T = new Tuple<int, double>(num1, num2);

            Console.WriteLine(line1T);
            Console.WriteLine(line2T);
            Console.WriteLine(line3T);
        }
    }
}
