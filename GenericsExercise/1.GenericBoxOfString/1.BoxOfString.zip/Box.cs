﻿using System;
namespace _1.GenericBoxOfString
{
    public class Box<T>
    {
        public T Line { get; set; }

        public Box(T line)
        {
            Line = line;
        }

        public override string ToString()
        {
            return $"{Line.GetType()}: {Line}";
        }
    }
}
