﻿using System;
using System.Collections.Generic;

namespace GenericCountMethodStringAndDouble
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            int n = int.Parse(Console.ReadLine());
            List<string> values = new List<string>();

            for (int i = 0; i < n; i++)
            {
                values.Add(Console.ReadLine());
            }

            string element = Console.ReadLine();
            Box<string> box = new Box<string>(values, element);
            Console.WriteLine(box.CountOfElementsBiggerThanInput());           
        }        
    }
}
