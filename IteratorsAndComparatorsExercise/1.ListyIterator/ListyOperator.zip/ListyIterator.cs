﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace _1.ListyIterator
{
    public class ListyIterator<T>
    {
        private int index;
        private List<T> collection { get; set; }

        public ListyIterator(List<T> list)
        {
            index = 0;
            collection = list;
        }

        public int Count => collection.Count;

        public bool Move()
        {
            if (HasNext())
            {
                index++;
                return true;
            }

            return false;
        }

        public bool HasNext()
        {
            if (index < Count - 1)
            {
                return true;
            }
            return false;
        }

        public void Print()
        {

            if (Count == 0)
            {
                throw new InvalidOperationException("Invalid Operation!");
            }

            Console.WriteLine(collection[index]);
        }
    }
}
