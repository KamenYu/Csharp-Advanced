﻿namespace _5.CarSalesman
{
    public class Car
    {
        public string Model { get; set; }

        public Engine Engine { get; set; }

        public string Weight { get; set; } = "n/a";

        public string Colour { get; set; } = "n/a";
    }
}
