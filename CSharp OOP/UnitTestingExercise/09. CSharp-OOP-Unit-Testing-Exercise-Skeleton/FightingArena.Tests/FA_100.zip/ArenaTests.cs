﻿
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Tests
{
    public class ArenaTests
    {
        //private Arena arena;

        //[SetUp]
        //public void Setup()
        //{
        //    arena = new Arena();
        //}

        //[Test]
        //public void CheckConstructorWors()
        //{
        //    Assert.IsNotNull(arena);
        //}

        //[Test]
        //public void CheckWarriorsGetter()
        //{
        //    IReadOnlyCollection<Warrior> warriors = arena.Warriors;

        //    Assert.IsNotNull(warriors);
        //}

        //[Test]
        //public void CheckCounter()
        //{
        //    arena.Enroll(new Warrior("Pesho", 20, 200));

        //    Assert.AreEqual(arena.Count, 1);
        //}

        //[Test]
        //public void CheckDoubleEnrolment()
        //{
        //    Warrior testWarior = new Warrior("Pesho", 20, 200);
        //    arena.Enroll(testWarior);

        //    Assert.Throws<InvalidOperationException>(() => arena.Enroll(testWarior));
        //}

        //[Test]
        //public void CheckEnrolment()
        //{
        //    int expected = arena.Count + 1;
        //    Warrior testWarior = new Warrior("Pesho", 20, 200);
        //    arena.Enroll(testWarior);

        //    Assert.That(expected, Is.EqualTo(1));
        //}

        //[Test]
        //public void CheckEnrolmentWithSameName()
        //{
        //    int expected = arena.Count + 1;
        //    Warrior testWarior = new Warrior("Pesho", 20, 200);
        //    arena.Enroll(testWarior);

        //    Assert.Throws<InvalidOperationException>(() => arena.Enroll(new Warrior("Pesho", 30, 50)));
        //}


        //[Test]
        //public void TestFightWithNullAttacker()
        //{
        //    Warrior testWarrior = new Warrior("Pesho", 20, 200);
        //    arena.Enroll(testWarrior);

        //    Assert.Throws<InvalidOperationException>(() => arena.Fight("Gosho", "Pesho"));
        //}

        //[Test]
        //public void TestFightWithNullDefender()
        //{
        //    Warrior testWarrior = new Warrior("Pesho", 20, 200);
        //    arena.Enroll(testWarrior);

        //    Assert.Throws<InvalidOperationException>(() => arena.Fight("Pesho", "Gosho"));
        //}

        //[Test]
        //public void TestFightWithLegitWarriors()
        //{
        //    Warrior firstWarrior = new Warrior("Ceko", 20, 200);
        //    Warrior secondWarrior = new Warrior("Gosho", 20, 100);
        //    arena.Enroll(firstWarrior);
        //    arena.Enroll(secondWarrior);

        //    arena.Fight("Ceko", "Gosho");

        //    Assert.That(firstWarrior.HP, Is.EqualTo(180));
        //    Assert.That(secondWarrior.HP, Is.EqualTo(80));
        //}


        private Arena arena;

        [SetUp]
        public void Setup()
        {
            //Arrange
            arena = new Arena();
        }

        [Test]
        public void ConstructorSetsACollectionThatIsNotNull()
        {
            //Act && Assert
            Assert.IsNotNull(arena.Warriors);
        }

        [Test]
        public void ConstructorSetsArenaThatIsNotNull()
        {
            //Act && Assert
            Assert.IsNotNull(arena);
        }

        [Test]
        public void EnrollThrowsIOEWhenInvalidWarriorIsAdded()
        {
            //Arrange
            Warrior warrior = new Warrior("A", 34, 78);

            //Act && Assert
            arena.Enroll(warrior);

            //Assert
            Assert.Throws<InvalidOperationException>(() => arena.Enroll(warrior));
        }

        [Test]
        public void EnrollingSameWarriorThrowsIOE()
        {
            Warrior warrior = new Warrior("A", 34, 78);
            arena.Enroll(warrior);

            Assert.Throws<InvalidOperationException>(() => arena.Enroll(warrior));
        }

        [Test]
        [TestCase("A", 34, 78)]
        public void EnrollShouldAddWarriorToCollection(
            string attackerName,
            int attackerDmg,
                int attackerHp)
        {
            //Arrange
            Warrior warrior = new Warrior(attackerName, attackerDmg, attackerHp);

            //Act && Assert
            arena.Enroll(warrior);
            int expectedCount = 1;
            bool isAnyAttacker = arena.Warriors.Any(n => n.Name == attackerName);

            //Assert
            Assert.AreEqual(expectedCount, arena.Count);
            Assert.IsTrue(isAnyAttacker);
        }

        [Test]
        [TestCase("A", "D")]
        public void AttackingShouldThrowIOEWhenWarriorsDoNotExist(string attacker, string defender)
        {
            //Arrange
            Warrior warrior = new Warrior(attacker, 90, 800);

            Assert.Throws<InvalidOperationException>(() => arena.Fight(attacker, defender));
            //Act
            arena.Enroll(warrior);

            //Assert
            Assert.Throws<InvalidOperationException>(() => arena.Fight(attacker, defender));
        }

        [Test]
        public void FightShouldWorkAsExpected()
        {
            //Arrange
            Warrior attacker = new Warrior("Golem", 60, 500);
            Warrior defender = new Warrior("Micro", 35, 1000);

            //Act
            arena.Enroll(attacker);
            arena.Enroll(defender);
            arena.Fight("Golem", "Micro");

            int attackerHP = arena.Warriors.FirstOrDefault(n => n.Name == "Golem").HP;
            int defenderHP = arena.Warriors.FirstOrDefault(n => n.Name == "Micro").HP;

            //Assert
            Assert.AreEqual(465, attackerHP);
            Assert.AreEqual(940, defenderHP);
        }
    }
    
}
