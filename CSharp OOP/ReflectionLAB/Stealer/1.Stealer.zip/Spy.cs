﻿using System;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Stealer
{
    public class Spy
    {
        public Spy()
        {
        }

        public string StealFieldInfo(string className, string[] fieldsToInvestigate)
        {
            StringBuilder result = new StringBuilder();
            result.AppendLine($"Class under investigation: {className}");

            Type type = Type.GetType(className);

            FieldInfo[] fields = type.GetFields(BindingFlags.NonPublic
                | BindingFlags.Instance
                | BindingFlags.Public
                | BindingFlags.Static);

            Object instance = Activator.CreateInstance(type, new object[] { });

            foreach (var field in fields.Where(f => fieldsToInvestigate.Contains(f.Name)))
            {
                result.AppendLine($"{field.Name} = {field.GetValue(instance)}");
            }

            return result.ToString().Trim();
        }
    }
}
