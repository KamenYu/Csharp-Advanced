﻿using System;

namespace Stealer
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Spy spy = new Spy();

            //string r = spy.StealFieldInfo("Stealer.Hacker", new string[] { "username", "password" }); 
            //Console.WriteLine(r);
            //Console.WriteLine(new string('.', 45));

            //string re = spy.AnalyzeAcessModifiers("Stealer.Hacker");
            //Console.WriteLine(re);
            //Console.WriteLine(new string('.', 45));

            string res = spy.RevealPrivateMethods("Stealer.Hacker");
            Console.WriteLine(res);

        }
    }
}
