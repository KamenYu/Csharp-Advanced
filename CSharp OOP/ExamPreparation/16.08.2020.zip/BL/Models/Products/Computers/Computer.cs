﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private readonly List<IComponent> components;
        private readonly List<IPeripheral> peripherals;

        public Computer(int id, string manufacturer, string model, decimal price, double overallPerformance)
            : base(id, manufacturer, model, price, overallPerformance)
        {
            components = new List<IComponent>();
            peripherals = new List<IPeripheral>();
        }

        public IReadOnlyCollection<IComponent> Components => components.ToList();

        public IReadOnlyCollection<IPeripheral> Peripherals => peripherals.ToList();

        public override decimal Price => Price + components.Sum(x => x.Price) + peripherals.Sum(x => x.Price);

        public override double OverallPerformance => components.Count == 0 ? OverallPerformance : OverallPerformance + components.Average(x => x.OverallPerformance);

        public void AddComponent(IComponent component)
        {
            if (components.Any(x => x.GetType().Name == component.GetType().Name))
            {
                throw new ArgumentException($"Component {component.GetType().Name} already exists in {GetType().Name} with Id {Id}.");
            }

            components.Add(component);
        }

        public IComponent RemoveComponent(string componentType)
        {
            IComponent component = components.FirstOrDefault(x => x.GetType().Name == componentType);

            if (component == null)
            {
                throw new ArgumentException($"Component {component.GetType().Name} does not exist in {GetType().Name} with Id {Id}.");
            }

            components.Remove(component);
            return component;
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (peripherals.Any(x => x.GetType().Name == peripheral.GetType().Name))
            {
                throw new ArgumentException($"Peripheral {peripheral.GetType().Name} already exists in {GetType().Name} with Id {Id}.");
            }

            peripherals.Add(peripheral);
        }
        
        public IPeripheral RemovePeripheral(string peripheralType)
        {
            IPeripheral peripheral = peripherals.FirstOrDefault(x => x.GetType().Name == peripheralType);

            if (peripheral == null)
            {
                throw new ArgumentException($"Component {peripheral.GetType().Name} does not exist in {GetType().Name} with Id {Id}.");

            }

            peripherals.Remove(peripheral);
            return peripheral;
        }

        public override string ToString()
        {
            StringBuilder result = new StringBuilder();

            result.AppendLine(base.ToString());
            result.AppendLine($" Components ({components.Count}):");
            foreach (var item in components)
            {
                result.AppendLine(item.ToString());
            }

            double AOP = peripherals.Count == 0 ? 0 : peripherals.Average(x => x.OverallPerformance);
            result.AppendLine($" Peripherals ({peripherals.Count}); Average Overall Performance ({AOP}):");

            foreach (var item in peripherals)
            {
                result.AppendLine(item.ToString());
            }

            return result.ToString().TrimEnd();
        }
    }
}
