﻿using System;
using System.Text;
using System.Linq;
using System.Collections.Generic;
using OnlineShop.Models.Products.Components;
using OnlineShop.Models.Products.Peripherals;
using OnlineShop.Models.Products.Computers;
using OnlineShop.Common.Enums;

namespace OnlineShop.Core
{
    public class Controller : IController
    {
        private List<IComponent> components;
        private List<IPeripheral> peripherals;
        private List<IComputer> computers;

        public Controller()
        {
            components = new List<IComponent>();
            computers = new List<IComputer>();
            peripherals = new List<IPeripheral>();
        }

        public string AddComputer(string computerType, int id, string manufacturer, string model, decimal price)
        {
            if (computers.Any(x => x.Id == id))
            {
                throw new ArgumentException("Computer with this id already exists.");
            }

            if (computerType == "Laptop")
            {
                computers.Add(new Laptop(id, manufacturer, model, price));
            }
            else if (computerType == "DesktopComputer")
            {
                computers.Add(new DesktopComputer(id, manufacturer, model, price));
            }
            else
            {
                throw new ArgumentException("Computer type is invalid.");
            }

            return $"Computer with id {id} added successfully.";
        }

        public string AddComponent(int computerId, int id, string componentType, string manufacturer, string model, decimal price, double overallPerformance, int generation)
        {
            ComputerExists(computerId);

            if (components.Any(x => x.Id == id))
            {
                throw new ArgumentException("Component with this id already exists.");
            }

            ComponentType componentT = new ComponentType();
            IComponent component = null;

            if (Enum.TryParse(componentType, out componentT) == false)
            {
                throw new ArgumentException("Component type is invalid.");
            }
            else if (componentT == ComponentType.CentralProcessingUnit)
            {
                component = new CentralProcessingUnit(id, manufacturer, model, price, overallPerformance, generation);
            }
            else if (componentT == ComponentType.Motherboard)
            {
                component = new Motherboard(id, manufacturer, model, price, overallPerformance, generation);
            }
            else if (componentT == ComponentType.PowerSupply)
            {
                component = new PowerSupply(id, manufacturer, model, price, overallPerformance, generation);
            }
            else if (componentT == ComponentType.RandomAccessMemory)
            {
                component = new RandomAccessMemory(id, manufacturer, model, price, overallPerformance, generation);
            }
            else if (componentT == ComponentType.SolidStateDrive)
            {
                component = new SolidStateDrive(id, manufacturer, model, price, overallPerformance, generation);
            }
            else if (componentT == ComponentType.VideoCard)
            {
                component = new VideoCard(id, manufacturer, model, price, overallPerformance, generation);
            }

            computers.FirstOrDefault(x => x.Id == computerId).AddComponent(component);
            components.Add(component);

            return $"Component {component.GetType().Name} with id {id} added successfully in computer with id {computerId}.";
        }

        

        public string AddPeripheral(int computerId, int id, string peripheralType, string manufacturer, string model, decimal price, double overallPerformance, string connectionType)
        {
            ComputerExists(computerId);

            if (peripherals.Any(x => x.Id == id))
            {
                throw new ArgumentException("Peripheral with this id already exists.");
            }

            IPeripheral peripheral = null;
            PeripheralType type = new PeripheralType();

            if (Enum.TryParse(peripheralType, out type) == false)
            {
                throw new ArgumentException("Peripheral type is invalid.");
            }
            else if (type == PeripheralType.Headset)
            {
                peripheral = new Headset(id, manufacturer, model, price, overallPerformance, connectionType);
            }
            else if (type == PeripheralType.Keyboard)
            {
                peripheral = new Keyboard(id, manufacturer, model, price, overallPerformance, connectionType);
            }
            else if (type == PeripheralType.Monitor)
            {
                peripheral = new Monitor(id, manufacturer, model, price, overallPerformance, connectionType);
            }
            else if (type == PeripheralType.Mouse)
            {
                peripheral = new Mouse(id, manufacturer, model, price, overallPerformance, connectionType);
            }

            computers.FirstOrDefault(x => x.Id == computerId).AddPeripheral(peripheral);
            peripherals.Add(peripheral);

            return $"Peripheral {peripheralType} with id {id} added successfully in computer with id {computerId}.";
        }

        public string BuyBest(decimal budget)
        {
            IComputer computer = computers.OrderByDescending(c => c.OverallPerformance).FirstOrDefault(x => x.Price <= budget);

            if (computers.Count == 0 || computer == null)
            {
                throw new ArgumentException($"Can't buy a computer with a budget of ${budget}.");
            }

            computers.Remove(computer);
            return computer.ToString();
        }

        public string BuyComputer(int id)
        {
            ComputerExists(id);

            IComputer computer = computers.FirstOrDefault(x => x.Id == id);

            if (computer == null)
            {
                return null;
            }
            else
            {
                computers.Remove(computer);
                return computer.ToString();
            }
        }

        public string GetComputerData(int id)
        {
            ComputerExists(id);

            IComputer computer = computers.FirstOrDefault(x => x.Id == id);

            if (computer == null)
            {
                return null;
            }
            else
            {
                return computer.ToString();
            }
        }

        public string RemoveComponent(string componentType, int computerId)
        {
            ComputerExists(computerId);

            IComponent component = components.FirstOrDefault(x => x.GetType().Name == componentType);

            if (component == null)
            {
                return null;
            }
            else
            {
                computers.FirstOrDefault(x => x.Id == computerId).RemoveComponent(component.GetType().Name);
                components.Remove(component);
                return $"Successfully removed {componentType} with id {component.Id}.";
            }
        }

        public string RemovePeripheral(string peripheralType, int computerId)
        {
            ComputerExists(computerId);

            IPeripheral peripheral = peripherals.FirstOrDefault(x => x.GetType().Name == peripheralType);

            if (peripheral == null)
            {
                return null;
            }
            else
            {
                computers.FirstOrDefault(x => x.Id == computerId).RemovePeripheral(peripheral.GetType().Name);
                peripherals.Remove(peripheral);
                return $"Successfully removed {peripheralType} with id {peripheral.Id}.";
            }
        }

        private void ComputerExists(int computerId)
        {
            if (computers.Any(x => x.Id == computerId) == false)
            {
                throw new ArgumentException("Computer with this id does not exist.");
            }
        }
    }
}
