﻿namespace EasterRaces.Core.Contracts
{
    public class IEngine
    {
    }
}
