﻿namespace WildFarm.Contracts
{
    public interface IProducingSoundForFood
    {
        public abstract string ProduceSoundSForFood();
    }
}
