﻿using System;
namespace WildFarm.Core
{
    public interface IEngine
    {
        void Run();
    }
}
