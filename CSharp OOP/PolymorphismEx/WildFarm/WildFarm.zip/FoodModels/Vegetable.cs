﻿using WildFarm.Base;

namespace WildFarm.FoodModels
{
    public class Vegetable : Food
    {
        public Vegetable(int quantity) : base(quantity)
        { }
    }
}
