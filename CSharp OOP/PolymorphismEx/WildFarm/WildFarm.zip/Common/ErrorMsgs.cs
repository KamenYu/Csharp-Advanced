﻿namespace WildFarm.Common
{
    public static class ErrorMsgs
    {
        public const string InvalidTypeMsg = "Invalid Type!";
    }
}
