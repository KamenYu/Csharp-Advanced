﻿namespace Vehicles
{
    public abstract class Vehicle
    {        
        public Vehicle(double fuelQ, double fuelC)
        {
            FuelQuantity = fuelQ;
            FuelConsumption = fuelC;
        }

        public double FuelQuantity { get; set; }
        public double FuelConsumption { get; set; }

        public virtual void Drive(double distance)
        { }

        public virtual void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }
    }
}
