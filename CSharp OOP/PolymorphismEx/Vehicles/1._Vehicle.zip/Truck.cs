﻿using System;
namespace Vehicles
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQ, double fuelC) : base(fuelQ, fuelC)
        { }

        double ExtraConsumtionForSummer = 1.6;

        public override void Drive(double distance)
        {
            double temp = FuelQuantity;
            FuelQuantity -= distance * FuelConsumption + distance * ExtraConsumtionForSummer; // hmmm

            if (FuelQuantity < 0)
            {
                FuelQuantity = temp;
                Console.WriteLine($"Truck needs refueling");
            }
            else
            {
                Console.WriteLine($"Truck travelled {distance} km");
            }
        }

        public override void Refuel(double fuel)
        {
            FuelQuantity += + (fuel * 0.95);
        }
    }
}
