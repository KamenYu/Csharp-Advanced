﻿using System;

namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(double fuelQ, double fuelC) : base(fuelQ, fuelC)
        { }

        double ExtraConsumtionForSummer = 0.9;

        public override void Drive(double distance)
        {
            double temp = FuelQuantity;
            FuelQuantity -= distance * FuelConsumption + distance * ExtraConsumtionForSummer; // hmmm

            if (FuelQuantity < 0)
            {               
                FuelQuantity = temp;
                Console.WriteLine($"Car needs refueling");
            }
            else
            {
                Console.WriteLine($"Car travelled {distance} km");
            }
        }
    }
}
