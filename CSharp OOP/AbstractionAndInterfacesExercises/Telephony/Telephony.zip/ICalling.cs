﻿namespace Telephony
{
    public interface ICalling
    {
        public string Calling(string num);
    }
}
