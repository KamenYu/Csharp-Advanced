﻿namespace Telephony
{
    public interface IBrowsing
    {
        public string Browsing(string url);
    }
}
