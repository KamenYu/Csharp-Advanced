﻿namespace Telephony
{
    public static class GlobalConstants
    {
        public const string InvalidNumMsg = "Invalid number!";
        public const string InvalidURLMsg = "Invalid URL!";
    }
}
