﻿namespace MillitaryElit.Enumerators
{
    public enum SoldierCorpsEnum
    {
        Airforces  = 1,
        Marines = 2
    }
}
