﻿namespace MillitaryElit
{
    public interface IPrivate
    {
        public decimal Salary { get; }
    }
}
