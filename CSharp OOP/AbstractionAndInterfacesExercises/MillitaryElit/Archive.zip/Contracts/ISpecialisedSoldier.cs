﻿using MillitaryElit.Enumerators;

namespace MillitaryElit.Contracts
{
    public interface ISpecialisedSoldier
    {
        SoldierCorpsEnum SoldierCorpsEnum { get; }
    }
}
