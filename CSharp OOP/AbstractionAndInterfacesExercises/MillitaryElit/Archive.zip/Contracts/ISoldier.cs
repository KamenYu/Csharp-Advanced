﻿namespace MillitaryElit
{
    public interface ISoldier
    {
        public string ID { get; }
        public string FirstName { get; }
        public string LastName { get; }
    }
}
