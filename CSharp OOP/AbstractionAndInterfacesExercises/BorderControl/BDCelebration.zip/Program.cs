﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<IBirthed> birthed = new List<IBirthed>();

            while (input != "End")
            {
                string[] id = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (id[0] == "Citizen")
                {
                    Citizen cit = new Citizen(id[1], int.Parse(id[2]), id[3], id[4]);
                    birthed.Add(cit);
                }               
                else if (id[0] == "Pet")
                {
                    Pet cutie = new Pet(id[1], id[2]);
                    birthed.Add(cutie);
                }

                input = Console.ReadLine();
            }

            string fakeIDSuffix = Console.ReadLine(); // it is "year" in the second task
            int counter = 0;

            foreach (var item in birthed)
            {
                int start = item.Birthdate.Length - fakeIDSuffix.Length;
                string sub = item.Birthdate.Substring(start, fakeIDSuffix.Length);

                if (sub == fakeIDSuffix)
                {
                    Console.WriteLine(item.Birthdate);
                    counter++;
                }                
            }
        }
    }
}
