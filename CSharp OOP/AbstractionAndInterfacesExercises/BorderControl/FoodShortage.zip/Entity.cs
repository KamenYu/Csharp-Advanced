﻿namespace BorderControl
{
    interface Entity
    {
        public string ID  { get; set; }
    }
}
