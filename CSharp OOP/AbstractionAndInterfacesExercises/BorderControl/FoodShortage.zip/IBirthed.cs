﻿using System;
namespace BorderControl
{
    public interface IBirthed
    {
        public string Birthdate { get; set; }
    }
}
