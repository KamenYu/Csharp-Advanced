﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string input = Console.ReadLine();
            List<Entity> entities = new List<Entity>();

            while (input != "End")
            {
                string[] id = input
                .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (id.Length == 3)
                {
                    Citizen cit = new Citizen(id[0], int.Parse(id[1]), id[2]);
                    entities.Add(cit);
                }
                else if (id.Length == 2)
                {
                    Robot rob = new Robot(id[0], id[1]);
                    entities.Add(rob);
                }

                input = Console.ReadLine();
            }

            string fakeIDSuffix = Console.ReadLine();

            foreach (var item in entities)
            {
                int start = item.ID.Length - fakeIDSuffix.Length;
                string sub = item.ID.Substring(start, fakeIDSuffix.Length);

                if (sub == fakeIDSuffix)
                {
                    Console.WriteLine(item.ID);
                }
            }
        }
    }
}
