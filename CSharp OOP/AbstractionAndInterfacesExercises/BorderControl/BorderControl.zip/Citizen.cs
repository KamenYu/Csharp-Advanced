﻿namespace BorderControl
{
    public class Citizen : Entity
    {
        public Citizen(string name, int age, string id)
        {
            Name = name;
            Age = age;
            ID = id;
        }


        public string Name { get; set; }

        public int Age { get; set; }

        public string ID { get; set; }
    }
}
