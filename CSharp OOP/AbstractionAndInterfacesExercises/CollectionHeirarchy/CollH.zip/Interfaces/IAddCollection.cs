﻿namespace CollectionHeirarchy.Interfaces
{
    public interface IAddCollection
    {
        public int Add(string item);
    }
}
