﻿namespace CollectionHeirarchy.Interfaces
{
    public interface IAddRemoveCollection : IAddCollection
    {
        public string Remove(); // string??
    }
}
