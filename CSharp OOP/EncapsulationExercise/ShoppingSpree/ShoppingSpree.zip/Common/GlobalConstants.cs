﻿namespace ShoppingSpree.Common
{
    public static class GlobalConstants
    {
        public const string NameErrorMsg = "Name cannot be empty";
        public const string MoneyErrorMsg = "Money cannot be negative";
    }
}
